public class Node <E>{
    E element;
    Node<E> next;
    Node<E> prev;

    public Node(E element, Node<E> prev, Node<E> next) {
        this.element = element;
        this.next = next;
        this.prev = prev;
    }


//    public void append(Node<E> list1, Node<E> list2)
//    {
//        while (list1.next!=null)
//        {
//            list1=list1.next;
//        }
//        list1.next = list2;
//    }
//
//
//    public Node<E> concat(Node<E> list1,Node<E> list2)
//    {
//        Node<E>  all=new Node<>(list1.element,list1.next);
//        Node<E>  head=all;
//        list1=list1.next;
//        all=all.next;
//        while (list1!=null)
//        {
//            all=new Node<>(list1.element,list1.next);
//            list1=list1.next;
//            if(list1==null) break;
//            all=all.next;
//        }
//        all.next=list2;
//        while (list2!=null)
//        {
//            all=new Node<>(list2.element,list2.next);
//            list2=list2.next;
//            all=all.next;
//        }
//        return head;
//    }

//    public void swap(Node<E>list,int i,int j)
//    {
//        E firstElement, lastElement ;
//        Node<E> pointer;
//        for (int k = 0; k <=i ; k++) {
//            if(k==i)
//            {
//                pointer=list;
//                firstElement= list.element;
//                int v=i;
//                while (v<=j)
//                {
//                    if(v==j)
//                    {
//                        lastElement= list.element;
//                        list.element=firstElement;
//                        pointer.element=lastElement;
//                    }
//                    else {
//                        v++;
//                    list=list.next;
//                    }
//                }
//            }
//            else
//            list=list.next;
//        }
//        }

    void swap(Node<E>list,int i,int j)
    {
        list=list.next;
        E firstElement, lastElement ;
        Node<E> pointer;
        for (int k = 0; k <=i&&list!=null; k++) {
            if (k == i) {
                pointer = list;
                firstElement = list.element;
                int v = i;
                while (v <= j && list != null) {
                    if(v==j)
                    {
                        lastElement= list.element;
                        list.element=firstElement;
                        pointer.element=lastElement;
                    }
                        v++;
                        list=list.next;

                }
            } else
                list = list.next;
        }
    }


// void p(Node<E> l){
//        Node<E> h=l;
////        h=h.next;
//        while (h!=null)
//        {
//            System.out.println(h.element);
//            h=h.next;
//        }
// }



    int size;
Node<E> head;
Node<E> first;
int count;
    public E getElement() {
        return element;
    }

    public Node<E> getNext() {
        return next;
    }

    public boolean equals(Object o) {
        if (o == null) return false;
        if (getClass() != o.getClass()) return false;
        DoublyLinkedList l = (DoublyLinkedList) o;
        if (size != l.size) return false;
        Node firstNode = head.next;
        Node l_firstNode = l.head.next;
        while (firstNode != null) {
            if (!firstNode.getElement().equals(l_firstNode.getElement())) return false;
            firstNode = firstNode.getNext();
            l_firstNode = l_firstNode.getNext();
        }
        return true;
    }

    public E removeLast(Node<E> x)
    {
     Node<E> prev=x.prev;
     Node<E> next=x.next;
     prev.next=next;
     next.prev=prev;
     size--;
     return x.element;
    }

//    {
//        Node<E> pointer=first.next.next;
//        Node<E> newest=new Node<>(20,pointer,pointer.next);
//        pointer.next.prev=newest;
//        pointer.next=newest;
//        count++;
//    }
}
