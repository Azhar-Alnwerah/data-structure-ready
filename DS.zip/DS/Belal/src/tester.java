public class tester {
    public static void main(String[] args) {

//        Node<Integer> t1=new Node<>(3,null);
//        Node<Integer> s1=new Node<>(2,t1);
//        Node<Integer> f1=new Node<>(1,s1);
//        Node<Integer> ei2=new Node<>(99,null);
//        Node<Integer> se2=new Node<>(88,ei2);
//        Node<Integer> si2=new Node<>(77,se2);
//        Node<Integer> fi2=new Node<>(66,si2);
//        Node<Integer> fo2=new Node<>(55,fi2);
//        Node<Integer> t2=new Node<>(44,fo2);
//        Node<Integer> s2=new Node<>(33,t2);
//        Node<Integer> f2=new Node<>(22,s2);
//        Node<Integer> X=f2.concat(f2,f1);
//        f2.swap(f2,2,5);

//        while (X!=null)
//        {
//            System.out.println(X.element);
//            X=X.next;
//        }
//        f2.addf(0,f2);
//
//        while (f2!=null)
//        {
//            System.out.println(f2.element);
//            f2=f2.next;
//        }
//}
//        Node<Integer> f;
//        Node<Integer> s;
//        Node<Integer> t;
//
//        Node<Integer> trailer=new Node<>(null,null,null);
//        Node<Integer> header=new Node<>(null,null,trailer);
//        trailer.prev=header;
//         f=new Node<>(1,header,header.next);
//         header.next.prev=f;
//         header.next=f;
//         s=new Node<>(2,header,header.next);
//        header.next.prev=s;
//        header.next=s;
//         t=new Node<>(3,header,header.next);
//        header.next.prev=t;
//        header.next=t;
//        Node<Integer> fo=new Node<>(4,header,header.next);
//        header.next.prev=fo;
//        header.next=fo;
//        header.swap(header,0,1);
//        header=header.next;
//        while (header.next!=null)
//        {
//            System.out.println(header.element);
//            header=header.next;
//        }


    }
}
