public class DoublyLinkedList<E> {
    int size;
    Node<E> head;
////    private int size=0;
////    private Node<E> header;
////    private Node<E> trailer;
////
////    public DoublyLinkedList() {
////        header=new Node<>(null,null,null);
////        trailer=new Node<>(null,null,header);
////        header.next=trailer;
////    }
////
////    public boolean isEmpty()
////    {
////        return size==0;
////    }
////    public int size()
////    {
////        return size;
////    }
////    public E first()
////    {
////        if (isEmpty())return null;
////        return header.next.element;
////    }
////    public E last()
////    {
////        if (isEmpty())return null;
////        return trailer.prev.element;
////    }
////    private void addBetween(E e,Node<E> next, Node<E> prev)
////    {
////        Node<E> newest = new Node<>(e,next,prev);
////        prev.next=newest;
////        next.prev=newest;
////        size++;
////
////    }
////    public void addFirst(E e)
////    {
////        addBetween(e,header.next,header);
////    }
////    public void addLast(E e)
////    {
////        addBetween(e,trailer,trailer.prev);
////    }
////    private E remove(Node<E> x)
////    {
////        Node<E> p=x.prev;
////        Node<E> n=x.next;
////        p.next=n;
////        n.prev=p;
////        size--;
////        return x.element;
////    }
////    public E removeFirst()
////    {
////        return remove(header.next);
////    }
////    public E removeLast()
////    {
////        return remove(trailer.prev);
////    }
////
////
////
//
//
//    private class Node<Integer>{
//        private Integer element;
//        Node<java.lang.Integer> prev;
//        Node<java.lang.Integer> next;
//
//        public Node(Integer element, Node<java.lang.Integer> prev, Node<java.lang.Integer> next) {
//            this.element = element;
//            this.prev = prev;
//            this.next = next;
//        }
//
////        public E removeLast(Node<Integer> list)
////        {
////            Node<E> pre=list.prev;
////            Node<E> nex=list.next;
////            pre.next=nex;
////            nex.prev=pre;
////            size--;
////            return list.element;
////        }
//
//
//
//
//        public void swap(Node<I> list,int i,int j)
//        {
//            E firstElement, lastElement ,z;
//
//            for (int k = 0; k <i ; k++) {
//                list=list.next;
//            }
//            firstElement=list.element;
//            for (int k=i; k <j ; k++) {
//                list=list.next;
//            }
//            list.element=firstElement;
//
//            lastElement=list.element;
////            z=firstElement;A
////            firstElement=lastElement;
////            lastElement=z;
//        }
//
//
//
//    }
}
