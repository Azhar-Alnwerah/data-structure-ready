//Cloning Objects Arrays
import java.util.Arrays;
public class HomeWork2 {
    public static void main(String[] args) {
        String[] names={"maram","rofaida"};
        String[] copy=names;
        System.out.println(Arrays.toString(copy));
    }
}
